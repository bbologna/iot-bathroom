﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net.Http;
using Windows.ApplicationModel.Background;
using Windows.Devices.Gpio;
using System.Threading;

// The Background Application template is documented at http://go.microsoft.com/fwlink/?LinkID=533884&clcid=0x409

namespace LogicalReadPhotoResistor
{
    public sealed class StartupTask : IBackgroundTask
    {
        private const int LED_PIN = 6;
        private const int RESISTOR_PIN = 5;

        private GpioPin ledPin;
        private GpioPin resistorPin;

        public void Run(IBackgroundTaskInstance taskInstance)
        {
            System.Diagnostics.Debug.Write("Hola");
            var gpioController = GpioController.GetDefault();
            ledPin = gpioController.OpenPin(LED_PIN);

            // Turn on led
            resistorPin = gpioController.OpenPin(RESISTOR_PIN);

            Timer timer = new Timer(CallBack, null, 10, 10);

            if (resistorPin.IsDriveModeSupported(GpioPinDriveMode.InputPullDown))
                resistorPin.SetDriveMode(GpioPinDriveMode.InputPullDown);
            else
                resistorPin.SetDriveMode(GpioPinDriveMode.Input);

            ledPin.Write(GpioPinValue.Low);
            ledPin.SetDriveMode(GpioPinDriveMode.Output);
        }

        private void CallBack(object sender)
        {
            System.Diagnostics.Debug.Write("Hola");
            var value = resistorPin.Read();
            ledPin.Write(value);
        }

    }
}
